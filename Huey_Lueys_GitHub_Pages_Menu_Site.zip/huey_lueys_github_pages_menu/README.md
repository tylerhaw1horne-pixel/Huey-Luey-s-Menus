# Huey Luey's Acworth Menus

Static menu page for QR code table signs.

## Easiest GitHub Pages setup

1. Create a new public GitHub repository named `huey-lueys-menus`.
2. Upload everything from this folder into that repository.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select **main** and **/root**, then save.
6. Wait a few minutes and open the published GitHub Pages link.
7. Use that live link for the QR code.

